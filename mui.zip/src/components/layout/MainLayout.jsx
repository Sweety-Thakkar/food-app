import React from 'react'
import SideBar from '../sidebar/SideBar'

const MainLayout = () =>
    <>
        <SideBar />
    </>




export default MainLayout
