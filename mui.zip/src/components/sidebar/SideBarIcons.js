
const SideBarIcons=[
    {
        id:0,
        label:"Pizza",
        img:"https://cdn-icons-png.flaticon.com/512/6978/6978255.png",
    },
    {
        id:1,
        label:"Burger",
        img:"https://cdn-icons-png.flaticon.com/512/877/877951.png"
    },
    {
        id:2,
        label:"Salad",
        img:"https://cdn-icons-png.flaticon.com/512/2515/2515183.png"
    },
    {
        id:3,
        label:"Tacos",
        img:"https://cdn-icons-png.flaticon.com/512/541/541768.png"
    },
    {
        id:4,
        label:"Wrap",
        img:"https://cdn-icons-png.flaticon.com/512/2619/2619574.png"
    },
    {
        id:5,
        label:"Fries",
        img:"https://cdn-icons-png.flaticon.com/512/4459/4459356.png"
    },
    {
        id:6,
        label:"Drink",
        img:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxfuGocYkW46jyNfbwKiISPBPR2wjAsnbdz1MEpp3H7g&usqp=CAU&ec=48665699"
    },

]
export default SideBarIcons