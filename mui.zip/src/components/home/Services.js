import service1 from "../../assets/service-01.png";
import service2 from "../../assets/service-02.png";
import service3 from "../../assets/service-03.png"



export const services = [
    {
        id:0,
        label:"Quick Delivery",
        img:service1,
    },
    {
        id:1,
        label:"Super Dine In",
        img:service2,
    },
    {
        id:2,
        label:"Easy Pick Up",
        img:service3,
    }
]